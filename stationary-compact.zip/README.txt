AHC order-four compact archive
Mode: stationary; starts scanned: 52,237,424
Complete runs retained: 29,848
All unresolved and exceptional runs are retained.
Ordinary runs are represented by a sample, first occurrences and saved examples.
groups.csv gives counts, non-null counts and extrema over the full campaign.
compact.sqlite contains retained runs and the original meta/sessions/tallies/examples.
Run IDs and all BLOBs are copied byte for byte.
The original search script SHA-256 matches the database configuration.

Numerical totals
near_flat: 19,409,961
near_zero: 6,126,915
nonflat_uphill: 26,672,800
unresolved: 27,748

Unresolved endpoints, full campaign
{
  "count": 27748,
  "worst_flat_error": 0.4999999899999164,
  "largest_min_entry": 5.697489320846894e-07
}

Verification checks archive contents and their agreement with the copied records.
Numerical stationarity and Hessian signs retain their original floating-point meaning.
Complex BLOBs use little-endian complex128, C-order, shape 4 by 4.
Hessian BLOBs use little-endian float64, ascending spectra, lengths 16 and 9.
The selected rows do not reconstruct the discarded floating-point endpoints.
The script, seed, run ID and version metadata specify how to regenerate their initial conditions.
Different numerical libraries can change rounding in initial matrices and subsequent solver paths.
